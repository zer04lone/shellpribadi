<?php

/**
 * @package  moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 * @doc https://docs.moodle.org/dev/String_API
 */
 
defined('MOODLE_INTERNAL') || die();
 
$string['plugintitle'] = 'Moodle webshell plugin - by Podalirius';