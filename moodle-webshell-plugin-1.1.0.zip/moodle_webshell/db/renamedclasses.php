<?php

/**
 * @package  moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 * @doc https://moodle.org/mod/forum/discuss.php?d=262403
 */

// Details of classes that have been renamed to fit in with autoloading.

defined('MOODLE_INTERNAL') || die();

